<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

        <div class="container-fluid">

            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
              </li>
              <li class="breadcrumb-item active">My Dashboard</li>
            </ol>

        <!-- Icon Cards -->
            <div class="row">
                <div class="col-md-8 col-xs-12 col-centered">
                    <div class="col-xs-12 col-centered">
                        <div class="row">
                            <div class="col-xs-6 col-centered">
                                <form  method = 'get' action = '<?php echo e(url("/home")); ?>'>
                                    <button class="button-two" type = 'submit'><span class="texto_blanco">ADMIN</span></button>
                                </form>
                            </div>
                            <div class="col-xs-6 col-centered">
                                <form class = 'col s3' method = 'get' action = '<?php echo url("noticia"); ?>/create'>
                                    <div class="sub-main">
                                      <button class="button-two" type = 'submit'><span class="texto_blanco">Crear Nueva Blog</span></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php if(Session::has('mensaje')): ?>
                       <div class="col-10 col-md-8 alert alert-info alineado_centro"><?php echo e(Session::get('mensaje')); ?></div>
                    <?php endif; ?>
                      <div class="col-md-12 col-centered">
                        <div class="table-responsive">
                            <table class='table table-striped' cellpadding="10">
                                <thead>
                                    <tr>
                                        <td>TITULO</td>
                                        <td>SUBTITULO</td>
                                        <td>IMAGEN</td>
                                        <td>BORRAR</td>
                                        <td>EDITAR</td>
                                        <td>INFO</td>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td>
                                            <?php echo $noticia->titulo; ?>

                                        </td>
                                        <td><?php echo e(substr(strip_tags($noticia->cuerpo),0,50)); ?><?php echo e(strlen(strip_tags($noticia->cuerpo)) > 50 ? "...":""); ?>

                                        </td>
                                        <td>
                                            <img class='largo_imagenes' src="<?php echo e(url($noticia->imagen)); ?>" alt="">
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('noticia.destroy', ['id' => $noticia->id])); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Eliminar</button>
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('noticia.edit', $noticia->id)); ?>" class = 'viewEdit noticia btn-primary btn-xs' data-link = '/noticia/<?php echo $noticia->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                                        </td>
                                        <td>
                                            <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/noticia/<?php echo $noticia->id; ?>'><i class = 'material-icons'>info</i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>    
                        </div>    
                    </div>
                    <?php echo $noticias->links(); ?>

                </div>

            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>