<?php $__env->startSection('content'); ?>

<div class="escondido">
    <div class="row">
        <div class="col-12 gusano_universal_blog m-t-100">
            <div class="alineado_centro textos_blog">
                <div class="row">
                    <div class="col-12 m-t-20">
                        <img class='w-100' src="<?php echo e(asset('img/blog_mini.png')); ?>" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class='alienado_centro m-t-20 m-b-30'>
                            <h1><?php echo $noticia->titulo; ?></h1>
                        </div>
                    </div>
                    <div class="col-12 m-b-20">
                        <div class="row justify-content-around">
                            <div class="col alienado_centro">
                                <a id='regresar_blog' href="<?php echo e(asset('/noticias')); ?>">
                                    <i  class="fas fa-chevron-left"></i>REGRESAR
                                </a>
                            </div>
                            <div class="col alienado_centro">
                                <span><?php echo e($noticia->created_at->toFormattedDateString()); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <img class='w-100' src="<?php echo url($noticia->imagen); ?>" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 m-t-30 m-b-70 cuerpo_blog">
                        <?php echo $noticia->cuerpo; ?>

                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>