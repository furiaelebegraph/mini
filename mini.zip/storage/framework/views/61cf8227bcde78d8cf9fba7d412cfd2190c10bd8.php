<?php $__env->startSection('contenido'); ?>

 <div class="content-wrapper">

      <div class="container-fluid">

        <?php if(Session::has('info')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('info')); ?>

            </div>
        <?php endif; ?>
        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('/home')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>
        <section class="contenedor">
            <section class="row row-centered">
                <div class="col-md-8 col-xs-12 col-centered">
                    <div class="row">
                        <div class="col-xs-6 col-centered">
                            <form  method = 'get' action = '<?php echo e(url("/home")); ?>'>
                                <button class="button-two" type = 'submit'><span class="texto_blanco">DASHBOARD</span></button>
                            </form>
                        </div>
                        <div class="col-xs-6 col-centered">
                            <form method = 'get' action = '<?php echo url("imagen"); ?>'>
                                <button class = 'btn btn-danger'>Ver todos las Imagenes</button>
                            </form>
                        </div>
                        
                    </div>
                </div>
                    <div class="col-xs-12 col-md-8 col-centered">
                        <div class='titulo_seccion'>
                            Crear Album
                        </div class='titulo_seccion'>
                    </div>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="alert alert-danger"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-md-8 col-centered formularios">
                        <form method = 'POST' action = '<?php echo url("imagen"); ?>/<?php echo $imagen->
                            id; ?>/update'> 
                            <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                            <div class="form-group">
                                <label for="nombre">Nombre</label>
                                <input id="nombre" name = "nombre" type="text" class="form-control" value="<?php echo $imagen->nombre; ?>"> 
                            </div>
                            <div class="form-group">
                                <label for="imagen">imagen</label>
                                <img src="<?php echo asset($imagen->imagen); ?>" alt="">
                                <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $imagen->imagen; ?>"> 
                            </div>
                            <div class="form-group">
                                <label for="orden">Orden</label>
                                <input id="orden" name = "orden" type="text" class="form-control" value="<?php echo $imagen->orden; ?>"> 
                            </div>
                            <div class="form-group">
                                <label for="orden">Activo</label>
                                <select class="form-control"  name="activo">
                                    <option selected="selected" value="<?php echo e($imagen->activo); ?>"><?php echo e($imagen->activo); ?></option>
                                    <option value="si">Si</option>
                                    <option value="no">No</option>
                                </select>
                            </div>
                            <button class = 'btn btn-primary' type ='submit'>Update</button>
                        </form>
 </div>

            </section>  
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>