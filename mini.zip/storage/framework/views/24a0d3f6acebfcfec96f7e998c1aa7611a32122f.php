    <script src="//cloud.tinymce.com/stable/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea',plugins: "lists" });</script>
<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-md-offset-4 error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class='alert alert-danger'><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <?php if(Session::has('info')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('info')); ?>

            </div>
        <?php endif; ?>
        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('/home')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 mb-12">
                    <h1>
                        Editar Producto
                    </h1>
                    <form method = 'get' action = '<?php echo url("producto"); ?>'>
                        <button class = 'btn btn-danger'>Ver Productos</button>
                    </form>
                    <br>
                    <form method = 'POST' action = '<?php echo url("producto"); ?>/<?php echo $producto->
                        id; ?>/update' enctype="multipart/form-data"> 
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-group m-b-30">
                            <label for="nombre">Nombre</label>
                            <input id="nombre" name = "nombre" type="text" class="form-control" value="<?php echo $producto->nombre; ?>"> 
                        </div>
                        <div class="form-group m-b-30">
                            <label for="imagen">imagen</label>
                            <img class='ancho_imagen_adminis' src="<?php echo asset($producto->imagen); ?>" alt="">
                            <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $producto->imagen; ?>"> 
                        </div>
                        <div class="form-group m-b-30">
                            <label for="imagen">Descripcion</label>
                            <textarea  id="descripcion" name = "descrip" type="text" class="form-control"><?php echo $producto->descripcion; ?></textarea> 
                        </div>

                        <?php if( $producto->color()->count() >0 ): ?>
                            <div class="form-group m-b-30">
                                <label for="color">Color</label>
                                 <select id='color' class="form-control"  name="id_color">
                                    <option selected="selected" value="<?php echo e($producto->color->id); ?>"><?php echo e($producto->color->nombre); ?></option>
                                    <?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($color->id); ?>"><?php echo e($color->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        <?php else: ?>
                            <div class="form-group m-b-30">
                                <label for="color">Color</label>
                                 <select id='color' class="form-control"  name="id_color">
                                    <option selected="selected" >Selecciona un color</option>
                                    <?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($color->id); ?>"><?php echo e($color->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                            </div>
                        <?php endif; ?>
                        <?php if( $tallasprodu->count() > 0 ): ?>
                            <div class="form-group m-b-30">
                                <label for="talla">Editar Talla</label>
                                    <?php $__currentLoopData = $tallas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="checkbox">
                                        <label>
                                            <input type="checkbox" 
                                                <?php $__currentLoopData = $tallasprodu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numerotalla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($talla->numero == $numerotalla->numero): ?>
                                                        checked
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             name="arrayTallas[]" value="<?php echo e($talla->id); ?>">
                                            <?php echo e($talla->numero); ?>

                                        </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        <?php else: ?>
                            <div class="form-group m-b-30">
                                <label for="color">Talla</label>

                                    <?php $__currentLoopData = $tallas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="arrayTallas[]" value="<?php echo e($talla->id); ?>">
                                            <?php echo e($talla->numero); ?>

                                        </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <div class="form-group m-b-30">
                            <label for="orden">Orden</label>
                            <input id="orden" name = "orden" type="text" class="form-control" value="<?php echo $producto->orden; ?>"> 
                        </div>
                        <div class="form-group m-b-30">
                            <label for="orden">Categoria</label>
                            <select id='cate' class="form-control"  name="id_categoria">
                                <option selected="selected" value="<?php echo e($producto->cate->id); ?>"><?php echo e($producto->cate->nombre); ?></option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group<?php echo e($errors->has('subcate') ? ' has-error' : ''); ?> m-b-30">
                            <label for="subcate" class="col-md-12 control-label">Sub Categoria</label>
                            <select name="id_subcategoria" class="form-control" id='subcate'>
                                 <option selected="selected" value="<?php echo e($producto->subcate->id); ?>"><?php echo e($producto->subcate->nombre); ?></option>
                            </select>
                        </div>
                        <div class="form-group m-b-30">
                            <label for="orden">Activo</label>
                            <select class="form-control"  name="activo">
                                <option selected="selected" value="<?php echo e($producto->activo); ?>"><?php echo e($producto->activo); ?></option>
                                <option value="si">Si</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <button class = 'btn btn-primary' type ='submit'>Update</button>
                    </form>
                    <div class="col-12 m-b-30">
                        <?php if($producto->ima->count() <= 0): ?>
                            <div class="jumbotron text-center">
                                <div class="container">
                                    <h1 class="jumbotron-heading">No hay fotos en esta Galeria</h1>
                                    <div class="card">
                                      <div class="card-block">
                                        <form method='POST' action="<?php echo url("imagen/cargarGale"); ?>" enctype="multipart/form-data">
                                            <input type="hidden" name = '_token' value = '<?php echo e(Session::token()); ?>'>
                                            <input type="hidden" name="id_producto" value=<?php echo e($producto->id); ?>>
                                            <input type="hidden" name="nombreProdu" value=<?php echo e($producto->nombre); ?>>
                                            <div class="form-group">
                                                <label  class="col-2 col-form-label" for="galeria">Agregar Galeria</label>
                                                <input  class="form-control" type="file" name="galeria[]" multiple>
                                            </div>

                                            <button class='text-right btn btn-primary' type='submit'>Update</button>
                                        </form>
                                      </div> 
                                    </div>
                                </div>
                            </div>

                        <?php else: ?>
                            <div class="jumbotron text-center">
                                <div class="container">
                                    <h1 class="jumbotron-heading">Galeria</h1>
                                    <div class="row">
                                        <div class="card-deck">
                                            <?php $__currentLoopData = $producto->ima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="card">
                                                <img class="card-img-top ancho_imagen_adminis" src="<?php echo e(asset($imagen->imagen)); ?>" alt="">
                                                <div class="card-block">
                                                    <a class="btn btn-primary" href="<?php echo e(route('imagen.edit', $imagen->id)); ?>">Editar</a>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        <?php endif; ?>
                    </div>
            </div>
        </div>
    </div>
<script>
    $(document).ready(function() {
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
          }
        })
            
        $('#cate').append(' Please choose one');
        $('#cate').on('change',function(e){
            var potato = e.target.value;
            console.log(potato);
            $.get('/ajaxSucate/'+ potato+'', function(data){

                $('#subcate').empty();
                $('#subcate').append('<option>Elije una opcion </option>');
                console.log(data);
                $.each(data, function(index, subcateObj){
                    $('#subcate').append('<option value="'+ subcateObj.id+'">'+ subcateObj.nombre +'</option>');
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>