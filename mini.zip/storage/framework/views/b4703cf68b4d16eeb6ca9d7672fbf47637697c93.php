<?php $__env->startSection('content'); ?>

<div class="escondido">
    <div class="row">
        <div class="col-12 gusano_universal_blog m-t-200">
            <div class="centro_baby">
                <div class="row">
                    <div class="col-12 m-t-20  m-b-30 wow zoomIn">
                        <img class='w-100' src="<?php echo e(asset('img/blog_mini.png')); ?>" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <div data-wow-delay:"0.5" class="row justify-content-center m-b-30 wow slideInLeft">
                            <div class="col-11 col-md-6">
                                <img class='w-100' src="<?php echo e(asset($noticia->imagen)); ?>" alt="">
                            </div>
                            <div class="col-11 col-md-6 textos_noticias">
                                <div class="row">
                                    <div class="col-12">
                                        <h2><?php echo e($noticia->titulo); ?></h2>
                                        <span><?php echo e($noticia->created_at->toFormattedDateString()); ?></span>
                                    </div>
                                    <div class="col-12">
                                        <p><?php echo e(substr(strip_tags($noticia->cuerpo),0,100)); ?><?php echo e(strlen(strip_tags($noticia->cuerpo)) > 100 ? "...":""); ?></p>
                                        <a href="detalle/<?php echo e($noticia->id); ?>">Ver mas</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 m-t-30 m-b-20 alienado_centro">
                        <?php echo e($noticias->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>