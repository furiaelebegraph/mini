<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">

        <?php if(Session::has('info')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('info')); ?>

            </div>
        <?php endif; ?>
        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('/home')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 mb-12">
                    <h1>
                        Editar banner
                    </h1>
                    <form method = 'get' action = '<?php echo url("banner"); ?>'>
                        <button class = 'btn btn-danger'>Ver banneres</button>
                    </form>
                    <br>
                    <form method = 'POST' action = '<?php echo url("banner"); ?>/<?php echo $banner->
                        id; ?>/update' enctype="multipart/form-data"> 
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-group">
                            <label for="nombre">Nombre del Banner</label>
                            <input id="nombre" name = "nombre" type="text" class="form-control" value="<?php echo $banner->nombre; ?>">
                        </div>
                        <div class="form-group">
                            <label for="url">URL Banner</label>
                            <input id="url" name = "url" type="text" class="form-control" value="<?php echo $banner->url; ?>">
                        </div>
                        <div class="form-group">
                            <label for="imagen">Imagen Banner</label>
                            <img src="<?php echo asset($banner->imagen); ?>" alt="">
                            <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $banner->imagen; ?>"> 
                        </div>
                        <button class = 'btn btn-primary' type ='submit'>Update</button>
                    </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>