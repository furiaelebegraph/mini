<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">

        <?php if(Session::has('info')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('info')); ?>

            </div>
        <?php endif; ?>
        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('/home')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12">
                <h1>
                    Editar SubCategoria
                </h1>
                <form method = 'get' action = '<?php echo url("subcategoria"); ?>'>
                    <button class = 'btn btn-danger'>Ver Sub Categorias</button>
                </form>
                <br>
                <form method = 'POST' action = '<?php echo url("subcategoria"); ?>/<?php echo $subcategoria->
                    id; ?>/update'> 
                    <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input id="nombre" name = "nombre" type="text" class="form-control" value="<?php echo $subcategoria->nombre; ?>"> 
                    </div>
                    <div class="form-group">
                        <label for="imagen">imagen</label>
                        <img src="<?php echo asset($subcategoria->imagen); ?>" alt="">
                        <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $subcategoria->imagen; ?>"> 
                    </div>
                    <div class="form-group">
                        <label for="orden">Orden</label>
                        <input id="orden" name = "orden" type="text" class="form-control" value="<?php echo $subcategoria->orden; ?>"> 
                    </div>
                    <div class="form-group">
                        <label for="orden">Categoria</label>
                        <select class="form-control"  name="id_categoria">
                            <option selected="selected" value="<?php echo e($subcategoria->cate->id); ?>"><?php echo e($subcategoria->cate->nombre); ?></option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="orden">Activo</label>
                        <select class="form-control"  name="activo">
                            <option selected="selected" value="<?php echo e($subcategoria->activo); ?>"><?php echo e($subcategoria->activo); ?></option>
                            <option value="si">Si</option>
                            <option value="no">No</option>
                        </select>
                    </div>
                    <button class = 'btn btn-primary' type ='submit'>Update</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>