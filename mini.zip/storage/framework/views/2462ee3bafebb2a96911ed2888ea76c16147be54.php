<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">

        <?php if(Session::has('info')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('info')); ?>

            </div>
        <?php endif; ?>
        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('/home')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 mb-12">
                    <h1>
                        Editar Categoria
                    </h1>
                    <form method = 'get' action = '<?php echo url("categoria"); ?>'>
                        <button class = 'btn btn-danger'>Ver Categorias</button>
                    </form>
                    <br>
                    <form method = 'POST' action = '<?php echo url("categoria"); ?>/<?php echo $categoria->
                        id; ?>/update' enctype="multipart/form-data"> 
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input id="nombre" name = "nombre" type="text" class="form-control" value="<?php echo $categoria->nombre; ?>">
                        </div>
                        <div class="form-group">
                            <label for="direccion">URL</label>
                            <input id="direccion" name = "direccion" type="text" class="form-control" value="<?php echo $categoria->url; ?>">
                        </div>
                        <div class="form-group">
                            <label for="imagen">imagen</label>
                            <img src="<?php echo asset($categoria->imagen); ?>" alt="">
                            <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $categoria->imagen; ?>"> 
                        </div>
                        <div class="form-group">
                            <label for="orden">Orden</label>
                            <input id="orden" name = "orden" type="text" class="form-control" value="<?php echo $categoria->orden; ?>"> 
                        </div>
                        <div class="form-group">
                            <label for="orden">Activo</label>
                            <select  class="form-control" name="activo">
                                <option selected="selected" value="<?php echo e($categoria->activo); ?>"><?php echo e($categoria->activo); ?></option>
                                <option value="si">Si</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <button class = 'btn btn-primary' type ='submit'>Update</button>
                    </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>