<?php $__env->startSection('content'); ?>

	<div class="escondido">
		<div class="row m-t-70 m-b-70 justify-content-center">
			<div class="col-12">
				<div class="centro_kids">
					<div class="row justify-content-between">
						<div class="col-12 alienado_centro">
							<div class="row justify-content-center align-items-start">
								<div class="col-9">
									<div class="regresar p-t-20 p-b-20">
										<a href="<?php echo e(url(strtolower ( $subcategoria->cate->url ))); ?>#seccion_catalogo_return">
											<i class="fas fa-angle-left"></i> Regresar
										</a>
									</div>
									
								</div>
							</div>
							<h1 class='titulo_generico_mini'> <?php echo e($subcategoria->nombre); ?>  </h1>
						</div>
					</div>
					<div class="row justify-content-center">
						<div class="col-12 col-sm-8">
							<div class="row justify-content-between">
								<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-11 col-sm-5 ">
										<div class="wrap_catalogo_kids">
											<a href=" <?php echo e(url('detalleproducto' , $producto->id)); ?> ">
												<img class='imagen_catalogo_kids' src="<?php echo e(asset( $producto->imagen )); ?>" alt="">
											</a>
										</div>
										<div class="m-t-20 alienado_centro">
											<a class='titulo_kids_cata' href=" <?php echo e(url('detalleproducto' , $producto->id)); ?>"> <?php echo e($producto->nombre); ?> </a>
										</div>
									</div>	
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>