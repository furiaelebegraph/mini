<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="Somos la empresa lider en calzado infantil. Tenemos el mejor surtido en zapatos escolares, zapatitos de bebe y zapatos de moda para niños">
    <meta name="robots" content="index,follow">
    <meta name="keywords" content="empresa lider en calzado infantil, venta de calzado infantil de piel, zapatos infantiles, zapatos de moda para niños, zapatos comodos para niños, zapatos resistentes para niños, zapatitos de bebe, zapatos escolares, venta de zapatos antiderrapantes para niños, zapatos para niños primeros pasos">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Miniburbujas')); ?></title>

    <!-- Styles -->
    <link href="https://use.fontawesome.com/releases/v5.0.8/css/all.css" rel="stylesheet">

    <link href="<?php echo e(asset('css/threesixty.css')); ?>" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/helpers.min.css')); ?>"  rel="stylesheet">
    <link href="<?php echo e(asset('css/animate.css')); ?>"  rel="stylesheet">
    <?php echo $__env->yieldContent('cssgaleria'); ?>
    <link href="<?php echo e(asset('css/general.css')); ?>"  rel="stylesheet">
    <!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-121775714-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-121775714-1');
	</script>
</head>
<body>

	<div id="navegacion_miniburbuajas">
		<div class="cambio_fondo fondo_change">
			<div>
				
			</div>
		</div>
			<div class="row justify-content-center align-items-center opciones_submenu">
				<div class="col-12 alienado_centro">
					<div class="cerrar_navega"> CERRAR </div>
					
				</div>
				<div class="col-12">
					<div class="centro_submenu">
						<div class="row justify-content-center align-items-center">
							<div class="col-7 col-sm-5 baby_navega margen_menu alienado_centro">
								<div>
									<a href="<?php echo e(url('baby')); ?>">
										<img class='icono_navegacion_menu' src="<?php echo e(asset('img/logo_baby_footer.svg')); ?>" alt="">
									</a>
								</div>
							</div>
							<div class="col-7 col-sm-5 primeros_navega margen_menu alienado_centro">
								<div>
									<a href="<?php echo e(url('primeros')); ?>">
										<img class='icono_navegacion_menu' src="<?php echo e(asset('img/logo_1eros_footer.svg')); ?>" alt="">
									</a>
								</div>
							</div>
							<div class="col-7 col-sm-5 kids_navega margen_menu alienado_centro">
								<div>
									<a href="<?php echo e(url('kids')); ?>">
										<img class='icono_navegacion_menu' src="<?php echo e(asset('img/logo_kids_footer.svg')); ?>" alt="">
									</a>
								</div>
							</div>

							<div class="col-7 col-sm-5 juvenil_navega margen_menu alienado_centro">
								<div> 
									<a href="<?php echo e(url('juvenil')); ?>">
										<img class='icono_navegacion_menu' src="<?php echo e(asset('img/logo_junior_footer.svg')); ?>" alt="">
									</a>
								</div>
							</div>

							<div class="col-7 col-sm-5 alienado_centro m-t-20">
								<div> <a href="<?php echo e(url('acerca')); ?>"><img class="icono_navegacion_menu" src="<?php echo e(asset('img/logo_blanco_mini.svg')); ?>" alt=""></a></div>
							</div>
							<div class="col-7 col-sm-5 alienado_centro m-t-20">
								<div> <a href="<?php echo e(url('proximamente')); ?>"><img class="icono_navegacion_menu" src="<?php echo e(asset('img/logo_blog.png')); ?>" alt=""></a></div>
							</div>
							<div class="col-7 col-sm-5 m-t-20">
								<div class="contacto_link"> <a href="<?php echo e(url('contacto')); ?>">CONTACTO</a></div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
	</div>
	<nav class="navbar-default navbar-static-top navegador_movil ">
		<div class="row align-items-center m-t-10">
			<div class="offset-0 offset-sm-1"></div>
			<div class="col-2 col-md-3 align-self-center">
				<div class="hamburguesita">
					<div id="nav-icon" class='nav-iconos'>
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
			</div>
			<div class="col-5 col-sm-4 alienado_centro align-self-center">
				<div class="d-flex justify-content-center align-items-center">			
					<div class="logo_veinticinco icono_veinticinco">
						<a href="<?php echo e(route('acerca')); ?>">
							<img src="http://elebeweb.com/test/mini/img/25aniv2.png" alt="">
						</a>
					</div>
					<div class="logo_header alienado_centro">
						<a href="<?php echo e(url('/')); ?>">
							<img src="<?php echo e(asset('img/logo_mini.png')); ?>" alt="">
						</a>
					</div>
				</div>
			</div>
			<div class="col-4 col-sm-3 alienado_centro align-self-center">
				<div class="row justify-content-center">
					<div class="col-12">
						<div class="d-flex justify-content-center justify-content-md-end">
							<div class="sociales_header">
								<div class="icono_social">
									<a target='_blank' href="https://www.facebook.com/miniburbujas/">
										<img src="<?php echo e(asset('img/ico_face.svg')); ?>" alt="">
									</a>
								</div>
							</div>
							<div class="sociales_header">
								<div class="icono_social">
									<a target='_blank' href="https://www.instagram.com/miniburbujas/">
										<img src="<?php echo e(asset('img/ico_instagram.svg')); ?>" alt="">
									</a>
								</div>
							</div>
							<div class="sociales_header">
								<div class="icono_social">
									<a target='_blank' href="https://www.youtube.com/channel/UCkVpFMUB7vrmaJ1TxlPEmZQ">
										<img src="<?php echo e(asset('img/ico_youtube.svg')); ?>" alt="">
									</a>
								</div>
							</div>
							<div class="sociales_header">
								<div class="icono_social">
									<a target='_blank' href="https://twitter.com/MiniBurbujas">
										<img src="<?php echo e(asset('img/ico_twitter_2.svg')); ?>" alt="">
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-12">
						<div class="btn_tienda_linea">
							<a target="_blank" href="<?php echo e(route('proximamente')); ?>">
								Tienda en línea 
							</a>
						</div>
					</div>
				</div>
			</div>
			<div class="offset-0 offset-sm-1"></div>
		</div>
	</nav>

	<?php echo $__env->yieldContent('content'); ?>

	<div class="row acerca_footer">
		<div class="col-12">
			<div class="footer alienado_centro">
				<div class="acerca_footer">
					<a href="<?php echo e(url('acerca')); ?>">ACERCA DE NOSOTROS</a>
				</div>
				<div class="nuestro_productos_footer">
					<div class="texto_bold">NUESTROS PRODUCTOS</div>
					<div class="iconos_productos_fotoer">
						<div class="icono_footer">
							<a href="<?php echo e(url('baby')); ?>">
								<img src="<?php echo e(asset('img/logo_baby_footer.svg')); ?>" alt="">
							</a>
						</div>
						<div class="icono_footer">
							<a href="<?php echo e(url('primeros')); ?>">
								<img src="<?php echo e(asset('img/logo_1eros_footer.svg')); ?>" alt="">
							</a>
						</div>
						<div class="icono_footer">
							<a href="<?php echo e(url('kids')); ?>">
								<img src="<?php echo e(asset('img/logo_kids_footer.svg')); ?>" alt="">
							</a>
						</div>
						<div class="icono_footer">
							<a href="<?php echo e(url('juvenil')); ?>">
								<img src="<?php echo e(asset('img/logo_junior_footer.svg')); ?>" alt="">
							</a>
						</div>
					</div>
				</div>
				<div class="contacto_footer m-b-10">
					<p class='texto_bold'> <a class="contacto_footer_link" href="<?php echo e(url('contacto')); ?> ">CONTACTO</a> </p>
					<a href="tel:+524777717373" class="texto_bold">
					    T. ( 477 ) 7717373
					</a>
					<div class='texto_bold'>
						correo electrónico: <br>
						hola@miniburbujas.mx
					</div>
				</div>
				<div class="redes_sociales_footer m-b-10">

					<div>
						<a target="_blank" href="https://www.facebook.com/miniburbujas/">
							<img src="<?php echo e(asset('img/icono_face_landing.svg')); ?>" alt="">
						</a>
					</div>
					<div>
						<a target="_blank" href="https://www.instagram.com/miniburbujas/">
							<img src="<?php echo e(asset('img/ico_instagram_blanco.svg')); ?>" alt="">
						</a>
					</div>
					<div>
						<a target="_blank" href="https://www.youtube.com/channel/UCkVpFMUB7vrmaJ1TxlPEmZQ">
							<img src="<?php echo e(asset('img/ico_youtube_blanco.svg')); ?>" alt="">
						</a>
					</div>
					<div>
						<a target="_blank" href="https://twitter.com/MiniBurbujas">
							<img src="<?php echo e(asset('img/icono_twitter.svg')); ?>" alt="">
						</a>
					</div>
				</div>
				<div class="footer_institucional p-b-50">
					<div class="marca texto_bold">
						Mini Burbujas®
					</div>
					<div class="aviso_privacidad">
						<a href="<?php echo e(url('aviso-privacidad')); ?>">Aviso de privacidad</a>
					</div>
					<div class="derechos texto_bold">
						2018 Mini Burbujas, Todos los derechos reservados.
					</div>
				</div>
			</div>
		</div>
	</div>

    <!-- Scripts -->
		<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('js/anime.js')); ?>"></script>
         <script src="<?php echo e(asset('js/wow.min.js')); ?> "></script>
         <?php echo $__env->yieldPushContent('jsgaleria'); ?>
         <?php echo $__env->yieldPushContent('js360'); ?>
        <script src="<?php echo e(asset('js/general.js')); ?>"></script>
</body>
</html>
        
