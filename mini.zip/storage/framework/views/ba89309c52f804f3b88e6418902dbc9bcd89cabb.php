<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

        <div class="container-fluid">

            <?php if(Session::has('info')): ?>
                <div class="alert alert-info">
                    <?php echo e(Session::get('info')); ?>

                </div>
            <?php endif; ?>
            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="<?php echo e(url('/home')); ?>">Dashboard</a>
              </li>
              <li class="breadcrumb-item active">My Dashboard</li>
            </ol>

        <!-- Icon Cards -->
            <div class="row">
                <div class="col-12 col-centered">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 col-centered">
                            <div class="row justify-content-center align-items-center">
                                <div class="col-6">
                                    <form  method = 'get' action = '<?php echo e(url("/home")); ?>'>
                                        <button class="button-two" type = 'submit'><span class="texto_blanco">ADMIN</span></button>
                                    </form>
                                </div>
                                <div class="col-6">
                                    <form class = 'col s3' method = 'get' action = '<?php echo url("categoria"); ?>/create'>
                                        <div class="sub-main">
                                          <button class="button-two" type = 'submit'><span class="texto_blanco">Crear Nueva Categoria</span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class='table table-striped'>
                                    <thead>
                                        <tr>
                                            <td>Categoria</td>
                                            <td>Subacategorias</td>
                                            <td>Imagen</td>
                                            <td>Orden</td>
                                            <td>BORRAR</td>
                                            <td>EDITAR</td>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <tr>
                                            <td><?php echo $categoria->nombre; ?></td>
                                            <td>
                                                <?php $__currentLoopData = $categoria->subcate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div>
                                                        <div><?php echo e($subcategoria->nombre); ?></div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td> 
                                                <img class='w-100' src="<?php echo $categoria->imagen; ?>" alt=""> 
                                            </td>
                                            <td>
                                                <?php echo e($categoria->orden); ?>

                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('categoria.destroy', ['id' => $categoria->id])); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Eliminar</button>
                                                    </div>
                                                </form>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('categoria.edit', $categoria->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/categoria/<?php echo $categoria->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </tbody>
                                </table>    
                            </div>    
                        </div>
                        <?php echo $categorias->links(); ?>

                    </div>
                </div>

            </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>