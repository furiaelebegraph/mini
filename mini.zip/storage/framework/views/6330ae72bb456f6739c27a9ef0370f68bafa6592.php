<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(url('/')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-comments"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($categorias->count()); ?> Categorias <br>
                </div>
              </div>
              <a href="<?php echo e(url('categoria')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas las Categorias</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('categoria.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVA Categoria</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>
          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-list"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($subcategorias->count()); ?> SubCategorias
                </div>
              </div>
              <a href="<?php echo e(url('subcategoria')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas las SubCategorias</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('subcategoria.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVA SubCategoria</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>

          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-list"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($tallas->count()); ?> Tallas
                </div>
              </div>
              <a href="<?php echo e(url('talla')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas las Tallas</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('talla.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVA Talla</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>

          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-list"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($colores->count()); ?> Colores
                </div>
              </div>
              <a href="<?php echo e(url('color')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas los Colores</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('color.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVA Colores</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>

          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-list"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($banneres->count()); ?> Banners
                </div>
              </div>
              <a href="<?php echo e(url('banner')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas los Banners</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('banner.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVO Banner</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>

          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-success o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-shopping-cart"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($productos->count()); ?> Productos
                </div>
              </div>
                <a href="<?php echo e(url('producto')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">Ver todas los Productos</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
                <a href="<?php echo e(route('producto.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVO Producto</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>
          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-list"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($tiendas->count()); ?> Tiendas
                </div>
              </div>
              <a href="<?php echo e(url('tienda')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas las Tiendas</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('tienda.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVA Tienda</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>
          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-list"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($noticias->count()); ?> BLOG
                </div>
              </div>
              <a href="<?php echo e(url('noticia')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todas las Entradas</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('noticia.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVA Entrada</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>
          <div class="col-12 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fa fa-fw fa-users"></i>
                </div>
                <div class="mr-5">
                  <?php echo e($clientes->count()); ?> CLIENTES
                </div>
              </div>
              <a href="<?php echo e(url('cliente')); ?>" class="card-footer text-white clearfix small z-1">
                <span class="float-left">Ver todos los clientes</span>
                <span class="float-right">
                  <i class="fa fa-angle-right"></i>
                </span>
              </a>
                <a href="<?php echo e(route('cliente.create')); ?>" class="card-footer text-white clearfix small z-1">
                    <span class="float-left">NUEVO cliente</span>
                    <span class="float-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </a>
            </div>
          </div>
        </div>


          <div class="col-lg-12">

            <!-- Card Columns Example Social Feed -->
            <div class="mb-0 mt-4">
              <i class="fa fa-newspaper-o"></i>
              Ultimos elementos creados</div>
            <hr class="mt-2">
            <div class="card-columns">

              <!-- Example Social Card -->
              <div class="card mb-3">
                
                <?php $__currentLoopData = $ultimoproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ultimoproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/producto/<?php echo $ultimoproducto->id; ?>">
                        <img class="card-img-top img-fluid w-100"  src="<?php echo e($ultimoproducto->imagen); ?>" alt="">
                    </a>
                    <div class="card-body">
                      <h6 class="card-title mb-1">
                        <a href="/producto/<?php echo $ultimoproducto->id; ?>"><?php echo e($ultimoproducto->nombre); ?></a>
                      </h6>
                      <p class="card-text small">These waves are looking pretty good today!
                        <a href="#">#surfsup</a>
                      </p>
                    </div>
                    <hr class="my-0">
                    <div class="card-body py-2 small">
                      <a class="mr-3 d-inline-block" href="/producto/<?php echo $ultimoproducto->id; ?>/edit">
                        <i class="fa fa-fw fa-edit"></i>
                        Editar
                      </a>
                      <a class="mr-3 d-inline-block" href="/producto/<?php echo $ultimoproducto->id; ?>/delete">
                        <i class="fa fa-fw fa-times"></i>
                        Eliminar
                      </a>
                    </div>
                    <div class="card-footer small text-muted">
                      Creado <?php echo e($ultimoproducto->created_at->toFormattedDateString()); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <!-- Example Social Card -->
              <div class="card mb-3">


                <?php $__currentLoopData = $ultimacates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ultimacate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/categoria/<?php echo $ultimacate->id; ?>">
                        <img class="card-img-top img-fluid w-100"  src="<?php echo e($ultimacate->imagen); ?>" alt="">
                    </a>
                    <div class="card-body">
                      <h6 class="card-title mb-1">
                        <a href="/categoria/<?php echo $ultimacate->id; ?>"><?php echo e($ultimacate->nombre); ?></a>
                      </h6>
                      <p class="card-text small">These waves are looking pretty good today!
                        <a href="#">#surfsup</a>
                      </p>
                    </div>
                    <hr class="my-0">
                    <div class="card-body py-2 small">
                      <a class="mr-3 d-inline-block" href="/categoria/<?php echo $ultimacate->id; ?>/edit">
                        <i class="fa fa-fw fa-edit"></i>
                        Editar
                      </a>
                      <a class="mr-3 d-inline-block" href="/categoria/<?php echo $ultimacate->id; ?>/delete">
                        <i class="fa fa-fw fa-times"></i>
                        Eliminar
                      </a>
                    </div>
                    <div class="card-footer small text-muted">
                      Creado <?php echo e($ultimacate->created_at->toFormattedDateString()); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>

            </div>
            <!-- /Card Columns -->

          </div>
        </div>

        <!-- Example Tables Card -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i>
            Data Table Example
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable">
                <thead>
                  <tr>
                    <th>Nombre</th>
                    <th>Imagen</th>
                    <th>Subcategoria</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                    <th>Nombre</th>
                    <th>Imagen</th>
                    <th>Subcategoria</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                  </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $prosdustos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prosdusto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($prosdusto->nombre); ?></td>
                        <td><img class="w-100" src="<?php echo e(asset($prosdusto ->imagen)); ?>" alt=""></td>
                        <td><?php echo e($prosdusto->subcate->nombre); ?></td>
                        <td>
                          <a href="<?php echo e(route('producto.edit', $prosdusto->id)); ?>" class = 'viewEdit btn btn-primary btn-xs'><i class = 'material-icons'>edit</i>
                        </td>
                        <td>
                          <form action="<?php echo e(route('producto.destroy', ['id' => $prosdusto->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <div class="form-group">
                              <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Eliminar</button>
                            </div>
                          </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
      <!-- /.container-fluid -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>