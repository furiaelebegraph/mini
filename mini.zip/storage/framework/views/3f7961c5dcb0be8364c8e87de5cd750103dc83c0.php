<?php $__env->startSection('content'); ?>

<div class="escondido fondo_proximamente">
	<div class="row justify-content-center align-items-center m-t-100 m-b-100">
		<div class="col-10 col-sm-8 col-md-5 m-t-50">
			<img src="<?php echo e(asset('img/proximamenter_tienda.svg')); ?>" alt="">
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>