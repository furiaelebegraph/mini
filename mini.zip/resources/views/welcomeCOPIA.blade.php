@extends('layouts.template')

@section('content')
<div class="row">
    <div class="col-12 landing_25aniv align-self-center">
        <div class="row align-items-center">
            <div class="col-12 m-t-70">
                <div class="logo_25aniv">
                    <img src="{{ asset('img/25aniv.png') }}" alt="">
                </div>
                
            </div>
            <div class="col-12 texto_header upperca alienado_centro py-5">
                <div class="panel-heading textoBold azulverde">Celebramos un año más </div>
                <div class="naranja textoBold">
                    <span>de</span> vanguardia y calidad
                </div>
                <div class="azulverde textoBold">
                    creando zapatos <span>de</span>
                </div>
                <div class="amarillo textoBold">
                    moda para niños.
                </div>
            </div>
            <div class="col-12">
                <div class="logo_mini_g">
                    <img src="{{ asset('img/logo_mini_g.png') }}" alt="">
                </div>
                
            </div>
        </div>

    </div>
</div>
<div class="row">
    <div class="col">
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        v
        v
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>
        potatobr    <br>v
        potatobr    <br>
    </div>
</div>
@endsection
