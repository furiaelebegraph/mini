@extends('layouts.template')

@section('content')

<div class="escondido">
	<div class="row">
		<div class="col-12 gusano_universal_blog">
			<div class="centro_baby">
				<div class="row">
					<div class="col-12">
						<img src="{{ asset('img/blog_mini.png') }}" alt="">
					</div>
				</div>
			</div>
		</div>
	</div> 
</div>



@endsection