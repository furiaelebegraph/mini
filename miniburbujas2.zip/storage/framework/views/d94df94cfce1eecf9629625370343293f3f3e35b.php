    <script src="//cloud.tinymce.com/stable/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea',plugins: "lists" });</script>
<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-md-offset-4 error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class='alert alert-danger'><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <?php if(Session::has('info')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('info')); ?>

            </div>
        <?php endif; ?>
        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 mb-12">
                    <h1>
                        Editar Tienda
                    </h1>
                    <form method = 'get' action = '<?php echo url("tienda"); ?>'>
                        <button class = 'btn btn-danger'>Ver Categorias</button>
                    </form>
                    <br>
                    <form method = 'POST' action = '<?php echo url("tienda"); ?>/<?php echo $tienda->
                        id; ?>/update'> 
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input id="nombre" name = "nombre" type="text" value='<?php echo e($tienda->nombre); ?>' class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="latitud">Coordenada 1</label>
                            <input id="latitud" name = "latitud" type="text" value='<?php echo e($tienda->Lat); ?>' class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="longitud">Coordenada 2</label>
                            <input id="longitud" name = "longitud" type="text" value='<?php echo e($tienda->Lng); ?>' class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="direccion">Descripcion</label>
                            <textarea  id="direccion" name = "direccion" type="text" class="form-control"> <?php echo $tienda->direccion; ?></textarea>
                        </div>
                        <button class = 'btn btn-primary' type ='submit'>Update</button>
                    </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>