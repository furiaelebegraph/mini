<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 mb-12">
                    <h1>
                        Editar Color
                    </h1>
                    <form method = 'get' action = '<?php echo url("color"); ?>'>
                        <button class = 'btn btn-danger'>Ver Colores</button>
                    </form>
                    <br>
                    <form method = 'POST' action = '<?php echo url("color"); ?>/<?php echo $color->
                        id; ?>/update' enctype="multipart/form-data"> 
                        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                        <div class="form-group">
                            <label for="color">Color</label>
                            <input id="color" name = "color" type="text" class="form-control" value="<?php echo $color->color; ?>">
                        </div>
                        <div class="form-group">
                            <label for="imagen">imagen</label>
                            <img src="<?php echo asset($color->imagen); ?>" alt="">
                            <input id="imagen" name = "imagen" type="file" class="form-control" value="<?php echo $color->imagen; ?>"> 
                        </div>
                        <button class = 'btn btn-primary' type ='submit'>Update</button>
                    </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>