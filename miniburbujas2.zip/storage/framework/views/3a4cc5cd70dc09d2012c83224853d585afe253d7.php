<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs -->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">My Dashboard</li>
        </ol>

        <!-- Icon Cards -->
        <div class="row">
          <div class="col-12 mb-12">
                <h1>
                    Editar Talla
                </h1>
                <form method = 'get' action = '<?php echo url("talla"); ?>'>
                    <button class = 'btn btn-danger'>Ver Talla</button>
                </form>
                <br>
                <form method = 'POST' action = '<?php echo url("talla"); ?>/<?php echo $talla->
                    id; ?>/update'> 
                    <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
                    <div class="form-group">
                        <label for="numero">Nombre</label>
                        <input id="numero" name = "numero" type="text" class="form-control" value="<?php echo $talla->numero; ?>"> 
                    </div>
                    <div class="form-group">
                        <label for="orden">Orden</label>
                        <input id="orden" name = "orden" type="text" class="form-control" value="<?php echo $talla->orden; ?>">
                    </div>
                    <button class = 'btn btn-primary' type ='submit'>Update</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>