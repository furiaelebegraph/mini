<?php $__env->startSection('contenido'); ?>
    <div class="content-wrapper">

        <div class="container-fluid">

            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
              </li>
              <li class="breadcrumb-item active">My Dashboard</li>
            </ol>

        <!-- Icon Cards -->
            <div class="row">
                <div class="col-md-12 col-xs-12 col-centered">
                    <div class="col-xs-12 col-centered">
                        <div class="row">
                            <div class="col-xs-6 col-centered">
                                <form  method = 'get' action = '<?php echo e(url("/home")); ?>'>
                                    <button class="button-two" type = 'submit'><span class="texto_blanco">ADMIN</span></button>
                                </form>
                            </div>
                            <div class="col-xs-6 col-centered">
                                <form class = 'col s3' method = 'get' action = '<?php echo url("producto"); ?>/create'>
                                    <div class="sub-main">
                                      <button class="button-two" type = 'submit'><span class="texto_blanco">Crear nuevo Producto</span></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="table-responsive">                            
                            <table class="table table-striped">

                                <thead>
                                    <tr>
                                        <td>Producto</td>
                                        <td>categoria</td>
                                        <td>subcategoria</td>
                                        <td>Imagen</td>
                                        <td>Orden</td>
                                        <td>BORRAR</td>
                                        <td>EDITAR</td>
                                        <td>INFO</td>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td> 
                                            <?php echo e($producto->nombre); ?>

                                        </td>
                                        <td>
                                            <?php echo e($producto->cate->nombre); ?>

                                        </td>
                                        <td>
                                            <?php echo e($producto->subcate->nombre); ?>

                                        </td>
                                        <td> 
                                            <img class='imagen_index' style='width:80px;' src="<?php echo $producto->imagen; ?>" alt=""> 
                                        </td>
                                        <td>
                                            <?php echo e($producto->orden); ?>

                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('producto.destroy', ['id' => $producto->id])); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Eliminar</button>
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('producto.edit', $producto->id)); ?>" class = 'viewEdit btn btn-primary btn-xs' data-link = '/subcategoria/<?php echo $producto->id; ?>/edit'><i class = 'material-icons'>edit</i></a>
                                        </td>
                                        <td>
                                            <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/subcategoria/<?php echo $producto->id; ?>'><i class = 'material-icons'>info</i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php echo $productos->links(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>