<?php $__env->startSection('cssgaleria'); ?>
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>" /> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class='m-t-100'>
			<div class="row justify-content-center">
				<div class="col-9 ">
					<div class="regresar p-t-20 p-b-20">
						<a href="<?php echo e(url()->previous()); ?>">
							<i class="fas fa-caret-left"></i> Regresar
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>


    <div class="row justify-content-center m-t-20 m-b-100">
        <div class="col-12 col-md-7" id="slider">
                <div id="myCarousel" class="carousel slide">
                    <!-- main slider carousel items -->
                    <div class="carousel-inner">
                    	<?php $__currentLoopData = $producto->ima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagenes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a data-fancybox="gallery" class='item carousel-item' data-slide-number="<?php echo e($key); ?>" href="<?php echo e(asset($imagenes->imagen)); ?>">
								<img class='w-100' src="<?php echo e(asset($imagenes->imagen)); ?>" alt="">
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a class="carousel-control left pt-3" href="#myCarousel" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
                        <a class="carousel-control right pt-3" href="#myCarousel" data-slide="next"><i class="fa fa-chevron-right"></i></a>

                    </div>
                    <!-- main slider carousel nav controls -->


                    <ul class="carousel-indicators list-inline m-t-60">
                    	<?php $__currentLoopData = $producto->ima; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagenes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class='list-inline-item'  data-slide-to="<?php echo e($key); ?>" data-target="#myCarousel" ">
								<a id="carousel-selector-<?php echo e($key); ?>" class="selected" data-slide-to="<?php echo e($key); ?>" data-target="#myCarousel">
	                                <img src="<?php echo e(asset($imagenes->imagen)); ?>" class="img-fluid">
	                            </a>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            </div>
        </div>
		<div class="col-8 col-md-4 margen_top_producto">
			<div class="row align-content-center">
				<div class="col-12 m-b-30">
					<img class='logo_detalle_producto' src=" <?php echo e(asset($producto->cate->imagen)); ?>" alt=""> 
				</div>
				<div class="col-12">
					<h2 class="nombre_producto">
						<?php echo e($producto->nombre); ?>

					</h2>
				</div>
				<div class="col-12 m-t-40">
					<h4 class="titulo nombres_categorias_producto">
						<a href="<?php echo e(url($producto->cate->url)); ?>"><?php echo e($producto->cate->nombre); ?></a> / <a href="<?php echo e(url('catalogo/'.$producto->subcate->id )); ?>"><?php echo e($producto->subcate->nombre); ?></a> 
					</h4>
				</div>
				<div class="col-12 m-t-30">
					<h2 class='titulo_catalogo'>
						Color
					</h2>
					
					<div class='color_gris detalle_color'>
						<?php if($producto->color()->count() > 0): ?>
							<p><?php echo $producto->color->nombre; ?></p>
							
							<img class='w-100' src="<?php echo e(asset($producto->color->imagen)); ?>" alt="">
						<?php else: ?>
							<p class='m-t-10 m-b-10'>No hay colores para mostrar.</p>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-12 linea_gris_cat"></div>
				<div class="col-12 m-t-30">
					<h2 class='titulo_catalogo'>
						Tallas
					</h2>
					<?php if($producto->talla()->count() > 0): ?>
						<ul class='row no-gutters justify-content-start align-items-center'>
							<?php $__currentLoopData = $producto->talla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numeros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class='col-10 col-sm-5 tallas_detalle'><?php echo e($numeros->numero); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					<?php else: ?>
						<p class='m-t-10 m-b-10'>No hay tallas para mostrar.</p>
					<?php endif; ?>
				</div>
				<div class="col-12 m-t-30">
					<h2 class='titulo_catalogo'>
						Descripcion
					</h2>
					
					<p class='color_gris'>
						<?php echo $producto->descripcion; ?>

					</p>
				</div>
			</div>
		</div>
    </div>

<?php $__env->stopSection(); ?>

	<?php $__env->startPush('jsgaleria'); ?>
    <!-- flot charts scripts-->
	    <script src="<?php echo e(asset('js/jquery.fancybox.min.js')); ?>"></script>
	<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>