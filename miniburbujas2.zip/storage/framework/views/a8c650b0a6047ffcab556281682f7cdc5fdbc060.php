<?php $__env->startComponent('mail::message'); ?>
# Hola, tienes un **correo nuevo** de

<?php $__env->startComponent('mail::panel'); ?>
	<?php echo e($data['nombre']); ?><br>
	<?php echo e($data['asunto']); ?><br>
	<?php echo e($data['correo']); ?><br>
	<?php echo e($data['mensaje']); ?>

<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>