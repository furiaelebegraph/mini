@extends('layouts.template')

@section('content')


<div class="escondido">
	<div class="row m-t-70 fondo_ciudad">
		<div class="col-12 fondo_lombris_cosmica">
		</div>
	</div>
</div>

@endsection